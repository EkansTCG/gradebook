public class Student {
  private String name;
  private String lastName;
  private Course[] courses;
  private int[] projectGrade;
  private int[] examGrade;
  private int projectLowest;
  private int courseNum;
  private int examNum;
  private int projectNum;

  public Student(String firstName, String lastName) {
    name = firstName;
    this.lastName = lastName;
    courses = new Course[6];
    courseNum = 0;
  }
  /*
   * This function is an accessor which would return the Student's full name.
   * 
   * @return Format:
   * name lastName
   */
  public String getName() {
    return name + " " + lastName;
  }
  /*
   * This function is an accessor which would return the Student's first name.
   * 
   * @return name
   */
  public String getFirstName() {
    return name;
  }
    /*
   * This function is an accessor which would return the Student's courses as a string
   * 
   * @return courses(converted to a String by a toString)
   */
  public String getCourse()
  {
    return toString(courses);
  }
  
  /*
   * This function cycles through all of the courses in the array Courses
   * and returns a string for each course that states the average exam grade
   * and average project grade
   */
  public void getGrades()
  {
    for(int i = 0; i < courseNum; i++)
    {
      System.out.println(courses[i].getName() + " \nExam grade: " + courses[i].getExamGrade() + "\nProject grade: " + courses[i].getProjectGrade() + "\n");
    }
  }

  /*
   * This function returns all of the average grades for the full Array of courses.
   *
   * This function is an accessor which would print the average project grade and average exam grade for the courses. Prints student does not take a specific course if necessary
   * 
   * @param courseName
  */ 
  public void getCourseGrade(String courseName)
  {
    Course thisCourse = findCourse(courseName);
    if (thisCourse != null)
    {
      System.out.println(courseName + ": \naverage project grade: " + thisCourse.getProjectGrade() + " \naverage exam grade: " + thisCourse.getExamGrade() + "\n");
    }   
    else if(thisCourse == null)
    {
      System.out.println("ERROR! " + name + " does not take course " + courseName);
    }
    
  }
  
  /*
   * This function is an accessor which would print the student's total grade for each course.
   */
  public void getReportCard()
  {
    System.out.println(name + "'s report card:");
    for(int i = 0; i < courseNum; i++)
    {
      System.out.println(courses[i].getName() + " Total grade: " + courses[i].getFinalGrade() + "\n");
    }
  }
  
  /*
   * This function adds projects to the Array of courses accordingly, if the course is listed within the Student object. 
   *
   *@param courseName, grade
   */

  public void addProject(String courseName, int grade)
  {
    Course thisCourse = findCourse(courseName);
    if(thisCourse != null)
    {
      thisCourse.addCourseProject(grade);
    }
    else
    {
      System.out.println("ERROR! " + name + " does not take course " + courseName);
    }
  }

  /*
   * This function adds exams to the Array of courses accordingly, if the course is listed within the Student object. 
   *
   *@param courseName, grade
   */
  public void addExam(String courseName, int grade)
  {
    Course thisCourse = findCourse(courseName);
    if(thisCourse != null)
    {
      thisCourse.addCourseExam(grade);
    }
    else
    {
      System.out.println("ERROR! " + name + " does not take course " + courseName);
    }
  }

  /*
   * This function creates a course object with the name courseName and adds that object to the courses array
   *
   *@param courseName, isCurved
   */
  public void enroll(String courseName, boolean isCurved) {
    if(courseNum < 6)
    {
      Course theCourse = new Course(courseName, isCurved);
      courses[courseNum] = theCourse;
      courseNum ++;   
    }
    else
    {
      System.out.println("ERROR! " + name + " is already enrolled in 6 courses! They cannot enroll in anymore");
    }
  }
  
  /*
   * This function checks whether the course is listed in the Student object 
   *
   *@param courseName, grade
   */
  public Course findCourse(String courseName)
  {
    if(courseName == null)
    { 
      return null;
    }
    for(Course course : courses)
    {
      if(course.getName().equalsIgnoreCase(courseName.toUpperCase()))
      {
        return course;
      }
    }
    return null;
  }
  
   /*
    toString that returns the elements inside the given array as a string
    @param int[] arr - the given array
    example return Format:
    element1, element2, element3, element4, element5, element6
  */ 
  public static String toString(Course[] arr) {
    String output = "";
    for (int i = 0; i < arr.length; i++) 
    {
      output += arr[i].getName();
      if (i != arr.length - 1) // if it is not the last number of the array
      {
        output += ", ";
      }
    }
    return output;
  }
 
}