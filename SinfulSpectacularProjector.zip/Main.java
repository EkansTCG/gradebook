import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
public class Main{
public static Student[] students;
public static void main(String[] args) throws FileNotFoundException, IOException {
  //array of 50 students
    students = new Student[50];
    fillBook();
  System.out.println("Welcome to the Stratfurd Gradebook");
  System.out.println("We will be testing three student's gradebooks.");
  Student Kevin = null;
  Student Omie = null;
  Student Riana = null;
  for(Student student: students)
  {
      if(student.getFirstName().equals("Kevin"))
      {
        Kevin = student;
      }
      else if(student.getFirstName().equals("Omie"))
      {
        Omie = student;     
      }
      else if(student.getFirstName().equals("Riana"))
      {
        Riana = student;
      }
  }
  System.out.println("These are the grades for Student Kevin.");
  System.out.println("Kevin takes the following courses: " + Kevin.getCourse());
  Kevin.addProject("Creative Writing", 100);
  Kevin.addProject("Creative Writing", 95);
  Kevin.addExam("Creative Writing", 88);
  Kevin.addProject("Creative Writing", 100);
  Kevin.addProject("Creative Writing", 95);
  Kevin.addExam("Creative Writing", 55);
  Kevin.addProject("Precalculus", 75);
  Kevin.addProject("Precalculus", 44);
  Kevin.addExam("Precalculus", 99);
  Kevin.addProject("Biology AP", 100);
  Kevin.addProject("Biology AP", 97);
  Kevin.addExam("Biology aP", 89);
  Kevin.addProject("World History AP", 97);
  Kevin.addExam("World History AP", 94);
  Kevin.addProject("Art II", 97);
  Kevin.addExam("Art II", 100);
  Kevin.addExam("Art II", 94);
  Kevin.addExam("Data Structures", 66);
  Kevin.addExam("Data Structures", 45);
  Kevin.addProject("Data Structures", 89);
  Kevin.addProject("Data Structures", 91);
  System.out.println("This is Kevin's grades in Creative Writing");
  Kevin.getCourseGrade("Creative Writing");
  Kevin.getReportCard();
  System.out.println("These are the grades for Student Omie.");
  System.out.println("Omie take the following courses: " + Omie.getCourse());
  Omie.addProject("English 9H",100);
  Omie.addProject("English 9H",89); 
  Omie.addExam("English 9H",93);
  Omie.addExam("English 9H",87);
  Omie.addExam("English 9H",97);
  System.out.println("Testing the user trying to imput more than 3 exams. The Program will return an error message: ");
  Omie.addExam("English 9H",93);
  Omie.addProject("Calculus bc",97);
  Omie.addExam("Calculus bc",89);
  Omie.addExam("Calculus bc",100);
  Omie.addProject("Physics",87);
  Omie.addProject("Physics",66);
  Omie.addExam("Physics",100);
  Omie.addProject("Art I",90);
  Omie.addExam("Art I",95);
  Omie.addExam("Art I",99);
  Omie.addProject("Data Structures",78);
  Omie.addExam("Data Structures",89);
  Omie.addExam("Data Structures",87);
  Omie.addProject("World History AP", 95);
  Omie.addProject("World History AP", 97);
  Omie.getReportCard();
  System.out.println("These are the grades for Student Riana.");
  System.out.println("Riana takes the following courses: " + Riana.getCourse());
  Riana.addProject("Creative Writing",100);
  Riana.addProject("Creative Writing",89); 
  Riana.addExam("Creative Writing",93);
  Riana.addProject("Algebra 2",97);
  Riana.addExam("Algebra 2",99);
  Riana.addExam("Algebra 2",100);
  Riana.addProject("Physics H",94);
  Riana.addProject("Physics H",96);
  Riana.addExam("Physics H",100);
  Riana.addProject("Choir",100);
  Riana.addExam("Choir",95);
  Riana.addExam("Choir",100);
  Riana.addProject("Computer Science A",100);
  Riana.addExam("Computer Science A",100);
  Riana.addExam("Computer Science A",100);
  Riana.addProject("World History AP", 95);
  Riana.addProject("World History AP", 100);
  Riana.addProject("Creative Writing",100);
  Riana.addProject("Creative Writing",99);
  System.out.println("These are all of Riana's grades: ");
  Riana.getGrades();
  Riana.getReportCard();
  }
public static void fillBook() throws FileNotFoundException, IOException {
  try(BufferedReader br = new BufferedReader(new FileReader("Gradebook.txt"))) {
   for(int i = 0; i < 50; i++ ) {
    String line = br.readLine();
     //cut the people out and put it into the other stuff and enroll
     int commaIndex = 0;
     //int previousComma = 0;
     String name = "";
     String lastName = "";
     String course1 = "";
     String course2 = "";
     String course3 = "";
     String course4 = "";
     String course5 = "";
     String course6 = "";
     Student a = null;

     for(int k = 0; k<8; k++)
      {
        System.out.println(line);
        if(k < 7)
        {
          commaIndex = line.indexOf(",");
        }
        if(k == 0)
        {
          lastName = line.substring(0, commaIndex);
        }
        else if(k == 1)
        {
          name = line.substring(0, commaIndex);
          a = new Student(name,lastName);
        }          
        else if(k == 2)
        {
          course1 = line.substring(0, commaIndex);
          //System.out.println(course1);
          if(course1.contains("AP"))
          {
            a.enroll(course1, true);
          }
          else
          {
            a.enroll(course1, false);
          }
        }
        else if(k == 3)
        {
          course2 = line.substring(0, commaIndex);
          //System.out.println(course2);
          if(course2.contains("AP"))
          {
            a.enroll(course2, true);
          }
          else
          {
            a.enroll(course2, false);
          }
        }
        else if(k == 4)
        {
          course3 = line.substring(0, commaIndex);
          //System.out.println(course3);
          if(course3.contains("AP"))
          {
            a.enroll(course3, true);
          }
          else
          {
            a.enroll(course3, false);
          }
        }
        else if(k == 5)
        {
          course4 = line.substring(0, commaIndex);
          if(course4.contains("AP"))
          {
            a.enroll(course4, true);
          }
          else
          {
            a.enroll(course4, false);
          }
        }
        else if(k == 6)
        {
          course5 = line.substring(0, commaIndex);
          //System.out.println(course5);
          if(course5.contains("AP"))
          {
            a.enroll(course5, true);
          }
          else
          {
            a.enroll(course5, false);
          }
        }
        else if(k == 7)
        {
          course6 = line.substring(0);
          //System.out.println(course6);
          if(course6.contains("AP"))
          {
            a.enroll(course6, true);
          }
          else
          {
            a.enroll(course6, false);
          }
        }
        if(k != 7)
        {
          line = line.substring(commaIndex + 2);
        }
        else
        {
          line = line.substring(commaIndex + 1);
        }
      }
     
     students[i] = a; 
  }
}
}
}