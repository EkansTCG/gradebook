public class Course {
  private int[] projectGrade;
  private int[] examGrade;
  private int examNum;
  private int projectNum;
  private int projectLowest;
  private String courseName;
  private boolean isCurved;

  public Course(String name, boolean curved) {
    courseName = name.toUpperCase();
    examNum = 0;
    projectNum = 0;
    projectLowest = 101;
    examGrade = new int[3];
    projectGrade = new int[6];
    isCurved = curved;
  }

  /*
   * This function is an accessor which would return the course name.
   * 
   * @return name
   */
  public String getName() {
    return courseName;
  }

  /*
    Adds a grade to the projectGrade array and checks if it is lower than the projectLowest; projectLowest will be changed in necessary. If the total number of projects becomes more than 6, this function prints an error message

    @param grade 
  */
  public void addCourseProject(int grade) {
    if (projectNum == 6) 
    {
      System.out.println("ERROR! You have already added 6 project grades. You cannot add anymore.");
    } 
    else {
      if (grade < projectLowest) 
      {
        projectLowest = grade;
      }
      projectGrade[projectNum] = grade;
      projectNum++;
    }
  }

  /*
    Adding exams into the examGrade array.  If the total number of exams becomes more than 3, this function would state that no more exams could be added.

    @param grade
  */
  public void addCourseExam(int grade) {
    if (examNum == 3) {
      System.out.println("ERROR! You have already added 3 exam grades. You cannot add anymore.");
    } else {
      examGrade[examNum] = grade;
      examNum++;
    }
  }
  
   /*
   * Finds and Returns the average project grade for the course and curves if this course requires a curve(if boolean isCurved is true)
   * 
   * @returns the average grade which is calculated by total(all the grades added up)/
   * projectNum(number of projects added so far)
   */
  public int getProjectGrade() {
    if(projectNum == 0)
    {
      return 100;
    }
    int total = 0;
    for (int i = 0; i < projectNum; i++) 
    {
      total += projectGrade[i];
    }
    if (projectNum == 1) 
    {
      return total;
    }
    if (isCurved) 
    {
      total = total - projectLowest;
      return total / (projectNum - 1);
    }
    return total / projectNum;
  }  
  
  /*
   * Finds and Returns the average exam grade for the course
   * 
   * @returns the average grade which is calculated by total(all the grades added up)/
   * examNum(number of Exams added so far)
   */
  public int getExamGrade() {
    if(examNum == 0)
    {
      return 100;
    }
    int total = 0;
    for (int i = 0; i < examNum; i++) {
      total += examGrade[i];
    }
    if(examNum == 0)
    {
      return 0;
    }
    else
    {
      return total / examNum;
    }
  }
  
  /*
    Returns the final grade of the course where the project average is 70% of the grade and the exam average is 30% of the grade
   
    @return double finalGrade - the calcuated average in the course that includes both project average and exam average
  */
  public double getFinalGrade() {
    double finalGrade = 0.7 * (getProjectGrade()) + 0.3 * (getExamGrade());
    return finalGrade;
  }


}